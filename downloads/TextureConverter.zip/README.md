# Texture Converter 1.0

Author / 作者　**Private0516**

完整解压本包，启动 `TextureConverter.exe`。选择单个材质、贴图或资源目录，输出到 Mod 根目录。两个工具共用同一个 Mod 根目录，分别生成 `meshes/`、`materials/` 和 `textures/`。转换前可选择是否保存报告。

On Windows x64, extract the entire archive and run `TextureConverter.exe`. The two tools can export to the same mod folder. Save reports is optional.

[GitHub Release](https://github.com/private200516/TextureConverter/releases/tag/v1.0) · [Source](https://github.com/private200516/TextureConverter/tree/v1.0)

本版 EXE 未进行 Windows Authenticode 签名。The Windows launcher is unsigned. SHA256SUMS.txt lists the package files. [Validation](SECURITY_VALIDATION.json) · [Build provenance](BUILD_PROVENANCE.json) · [Security](SECURITY.md).

项目代码采用 GPL-3.0，第三方组件按随附许可分发。开发使用 GPT-6 Astra，代码和界面含 AI 生成内容。
