# TextureConverter — ALPHA 1.0

Author: private0516 · Developed with GPT-6 Astra · AI-generated code and UI

Current revision: **security-hardening-20261117**. 两款程序仍独立运行、分别下载。

完整解压，保留 EXE、app/、runtime/、vendor/ 与许可目录，使用普通用户权限启动。不要混合旧版依赖或仅复制 EXE；旧窗口请先正常关闭。需要 Windows x64；Mesh 还需要系统已安装 Microsoft Edge WebView2 Runtime。

安全更新通过 399 项回归及针对性的原生界面、进程和转换检查。详见 [安全修订](SECURITY_REVISION_20261117.md)、[安全边界](SECURITY.md)、[测试摘要](SECURITY_VALIDATION.json) 与 [构建记录](BUILD_PROVENANCE.json)。启动器仍未签名，Python 保留 3.12.14；本包不承诺绝对安全。

SHA256SUMS.txt/PUBLIC_MANIFEST.json 记录本包文件身份。分享日志/配置前检查其中本地路径。GPL-3.0 与第三方通知保留；不包含用户游戏资产。历史动效验证见 MOTION_REVISION_20261117.md，历史恢复验证见 VALIDATION_20261117.md。

English: Extract the complete folder, restart old windows, and run the matching EXE as a normal user. The applications are separate downloads. See SECURITY.md for limits, SECURITY_VALIDATION.json for test results and BUILD_PROVENANCE.json for dependency identity. This revision retains the existing bilingual UI and native motion.
