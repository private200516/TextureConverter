# TextureConverter — portable Windows release / 便携版

Extract the entire archive to a writable local folder, keep its directory layout,
then run `TextureConverter.exe`. The Python/Qt runtime, vendor dependencies,
`texconv.exe`, fonts, icon and third-party notices are included. Use separate
input/output folders and keep backups of your own resources.

请完整解压后运行 `TextureConverter.exe`，不要单独移动 EXE 或删除随附依赖。
输入和输出请使用不同目录，并保留自有资源备份。材质工作流以 76→4 为已记录范围，
不把预检结果视为所有资源都可转换的保证。

Two recorded material conversion runs each committed two backend items with
no backend item errors; four output material headers were valid version 2.
Warnings remained, and the user's separate GUI error/skip prompt is unresolved.
Normal program exit and backend output do not establish complete GUI acceptance.
两次小范围材质操作各提交两项，后台未记录项目错误，四份输出材质头为有效 v2；
仍存在警告，用户另行观察到的 GUI 错误或跳过提示尚未定位，不能据此宣称界面验收通过。

Native DDS encoding coverage, a broad game corpus, gameplay, GUI latency,
maximum compatibility and complete security remain unverified.
原生 DDS 编码、广泛游戏资源、游戏内表现、界面延迟、最大兼容性和完整安全性仍待验证。

Retained runtime, program, UI, fonts and icon are byte-identical to the pinned B6
source archive. Build logs, private audit/provenance records and old reports are
not included. See `PUBLIC_MANIFEST.json`, `SHA256SUMS.txt`, `LICENSE`,
`THIRD_PARTY_NOTICES.txt`, `licenses/` and the vendor package license metadata.
Do not redistribute game assets or other material without appropriate rights.
请遵守随附许可证；游戏资源及其他素材的使用和再分发权须由使用者自行确认。
