# TextureConverter — ALPHA 1.0

> **最新动效版本 / Latest motion revision:** 2026-11-17 Pinterest motion. 启动 1400ms、关闭 650ms；323 项回归通过。详见 [MOTION_REVISION_20261117.md](MOTION_REVISION_20261117.md)。

Author: private0516 · Developed with GPT-6 Astra · AI-generated code and UI

## 2026-11-17 运行修复与动效更新

优化动画调度、页面/About 过渡和日志刷新；修复按钮交互及跨任务计数。 启动器和随附运行库保留；应用源文件已更新。本包并非与旧 B6 发布包逐字节相同。

完整解压后运行同名 EXE，保留 app/、runtime/、vendor/ 及许可证目录。需要 Windows x64；Mesh 还需要已安装的 Microsoft Edge WebView2 Runtime。请使用独立输出目录。

两个程序独立运行、分别下载。已打开的旧窗口需要重新启动后才能加载更新。详见 VALIDATION_20261117.md。

测试使用合成 NIF、BGSM/BGEM 和小尺寸 DDS；没有复测广泛游戏资产或游戏内表现。反向 Texture 仅验证材质。Mesh 预览帧率是同机 Chrome 测试结果，Qt 的 16ms 调度也不代表任何负载下都稳定达到 60fps。

Extract the entire archive and run TextureConverter.exe. Keep all accompanying folders. This is the local 2026-11-17 motion revision, still ALPHA 1.0. Application files were updated; the launcher and dependency runtime are retained. See VALIDATION_20261117.md for validation scope. This archive is not byte-identical to the earlier B6 publication.

See LICENSE, THIRD_PARTY_NOTICES.txt, licenses/ and dependency metadata for the existing project and third-party notices. No game fixtures are included in this update.
